@extends('app')
@section('title', config('rayarent.nama').' · '.config('rayarent.tagline'))
@php
    $rp = fn ($n) => 'Rp'.number_format($n, 0, ',', '.');
    $wa = preg_replace('/\D/', '', (string) config('rayarent.whatsapp'));
    $waLink = $wa ? 'https://wa.me/'.$wa.'?text='.rawurlencode('Halo '.config('rayarent.nama').', saya mau tanya sewa kendaraan.') : null;
    // kolom tabel harga: [layanan, durasi]
    $kolom = [['lepas_kunci', 12], ['lepas_kunci', 24], ['driver', 24], ['driver_bbm', 24]];
    $harga = fn ($v, $s, $d) => $v->packages->first(fn ($p) => $p->service === $s && (int) $p->duration_hours === $d)?->price;
@endphp
@section('content')

{{-- ============ PEMBUKA ============ --}}
<section class="lp-hero">
    <div class="lp-hero__text">
        <p class="lp-eyebrow">Rental mobil &amp; minibus</p>
        <h1>Sewa kendaraan per 12 atau 24 jam, lepas kunci atau dengan driver.</h1>
        <p class="lp-lead">
            Lihat harga di bawah, pilih tanggal, dan cek unit yang kosong langsung di website.
            Bayar DP {{ $dpPercent }}% lewat transfer, sisanya saat serah terima.
        </p>
        <div class="row mt-2">
            <a href="#harga" class="btn btn-lg">Lihat daftar harga</a>
            @if ($waLink)
                <a href="{{ $waLink }}" class="btn btn-lg btn-outline" rel="noopener">Tanya via WhatsApp</a>
            @else
                <a href="{{ route('register') }}" class="btn btn-lg btn-outline">Buat akun</a>
            @endif
        </div>
    </div>

    <dl class="lp-facts">
        <div><dt>Jenis kendaraan</dt><dd>{{ $vehicles->count() }}</dd></div>
        <div><dt>Unit siap jalan</dt><dd>{{ $totalUnit }}</dd></div>
        <div><dt>Harga mulai</dt><dd>{{ $rp($hargaTermurah) }}<small>/ paket</small></dd></div>
        <div><dt>Kapasitas sampai</dt><dd>{{ $kursiTerbanyak }}<small>kursi</small></dd></div>
    </dl>
</section>

{{-- ============ ARMADA ============ --}}
<section class="lp-section" id="armada">
    <div class="lp-head">
        <h2>Armada</h2>
        <p class="muted">Diurutkan dari harga termurah. Jumlah unit tidak termasuk yang sedang perawatan.</p>
    </div>

    @if ($vehicles->isEmpty())
        <div class="card empty"><strong>Daftar armada sedang diperbarui</strong>Silakan hubungi kami untuk info ketersediaan.</div>
    @else
    <div class="vgrid">
        @foreach ($vehicles as $v)
            <article class="vcard">
                <div class="vcard__media">
                    @if ($v->photo_url)
                        <img src="{{ $v->photo_url }}" alt="{{ $v->name }}" loading="lazy">
                    @else
                        <span class="media-placeholder" aria-hidden="true">{{ $v->capacity >= 14 ? '🚐' : ($v->capacity <= 4 ? '🚗' : '🚙') }}</span>
                    @endif
                </div>
                <div class="vcard__body">
                    <h3 class="vcard__title">{{ $v->name }}</h3>
                    <div class="vcard__chips">
                        <span class="chip">{{ $v->seat_label }} kursi</span>
                        @if ($v->transmission) <span class="chip">{{ $v->transmission }}</span> @endif
                        <span class="chip">{{ $v->units_count }} unit</span>
                    </div>
                    <p class="muted small" style="margin:0">{{ $v->packages->pluck('service_label')->unique()->implode(' · ') }}</p>
                    <div class="vcard__foot">
                        <div class="price"><small>Mulai dari</small>{{ $rp($v->min_price) }}</div>
                        <a class="btn btn-sm" href="{{ route('pelanggan.pesan', $v) }}">Pesan</a>
                    </div>
                </div>
            </article>
        @endforeach
    </div>
    @endif
</section>

{{-- ============ HARGA ============ --}}
<section class="lp-section" id="harga">
    <div class="lp-head">
        <h2>Daftar harga</h2>
        <p class="muted">Harga per paket. Sewa lebih lama dihitung kelipatan paket, misalnya 3 hari = 3 × paket 24 jam.</p>
    </div>

    <div class="table-wrap">
        <table class="lp-price">
            <thead>
                <tr>
                    <th scope="col">Kendaraan</th>
                    <th scope="col" class="text-right">Lepas kunci<br><span>12 jam</span></th>
                    <th scope="col" class="text-right">Lepas kunci<br><span>24 jam</span></th>
                    <th scope="col" class="text-right">Dengan driver<br><span>24 jam</span></th>
                    <th scope="col" class="text-right">Driver + BBM<br><span>24 jam</span></th>
                </tr>
            </thead>
            <tbody>
                @foreach ($vehicles->sortBy('capacity') as $v)
                    <tr>
                        <th scope="row">{{ $v->name }} <span class="muted small nowrap">· {{ $v->seat_label }} kursi</span></th>
                        @foreach ($kolom as [$s, $d])
                            @php $p = $harga($v, $s, $d); @endphp
                            <td class="text-right nowrap" data-label="{{ $services[$s] }} {{ $d }} jam">{!! $p ? e($rp($p)) : '<span class="lp-na">tidak tersedia</span>' !!}</td>
                        @endforeach
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <p class="small muted mt-1">Paket driver belum termasuk BBM, tol, parkir, dan makan driver kecuali tertulis "Driver + BBM". Tol dan parkir tetap ditanggung penyewa.</p>
</section>

{{-- ============ CARA SEWA ============ --}}
<section class="lp-section" id="cara-sewa">
    <div class="lp-head"><h2>Cara sewa</h2></div>
    <ol class="lp-steps">
        <li>
            <h3>Buat akun</h3>
            <p>Cukup nama, email, dan nomor HP yang aktif. Kami menghubungi nomor ini untuk konfirmasi.</p>
        </li>
        <li>
            <h3>Pilih paket &amp; tanggal</h3>
            <p>Sistem menampilkan unit yang masih kosong di jam yang Anda pilih, jadi tidak ada pesanan dobel.</p>
        </li>
        <li>
            <h3>Transfer DP {{ $dpPercent }}%</h3>
            <p>Unggah foto bukti transfer di halaman pesanan. Admin mengecek lalu mengonfirmasi pesanan Anda.</p>
        </li>
        <li>
            <h3>Ambil kendaraan</h3>
            <p>Lunasi sisa tagihan saat serah terima, tunai atau transfer. Kembalikan tepat waktu.</p>
        </li>
    </ol>
</section>

{{-- ============ KETENTUAN ============ --}}
<section class="lp-section lp-terms" id="ketentuan">
    <div class="lp-head"><h2>Yang perlu diketahui</h2></div>
    <dl>
        <div><dt>Uang muka</dt><dd>{{ $dpPercent }}% dari total sewa. Anda juga bisa langsung bayar lunas.</dd></div>
        <div><dt>Keterlambatan</dt><dd>{{ $rp($lateFee) }} per jam, dihitung dibulatkan ke atas sejak jam selesai sewa.</dd></div>
        <div><dt>Kerusakan</dt><dd>Kondisi kendaraan dicek saat dikembalikan. Biaya kerusakan, jika ada, ditambahkan ke tagihan.</dd></div>
        <div><dt>Pembatalan</dt><dd>Bisa dibatalkan sendiri dari akun selama belum ada pembayaran. Jika sudah transfer, hubungi admin.</dd></div>
    </dl>
</section>

{{-- ============ PENUTUP ============ --}}
<section class="lp-cta">
    <div>
        <h2>Sudah tahu mau sewa apa?</h2>
        <p>Pesan sekarang dan cek unit yang kosong{{ config('rayarent.jam_operasional') ? '. '.config('rayarent.jam_operasional') : '' }}.</p>
    </div>
    <div class="row">
        <a href="{{ route('register') }}" class="btn btn-lg lp-cta__btn">Daftar &amp; pesan</a>
        @if ($waLink) <a href="{{ $waLink }}" class="btn btn-lg lp-cta__ghost" rel="noopener">WhatsApp</a> @endif
    </div>
</section>
@endsection
